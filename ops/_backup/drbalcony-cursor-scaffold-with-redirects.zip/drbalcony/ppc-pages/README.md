# PPC Pages
One folder per landing page URL. Keep assets local; reuse components.