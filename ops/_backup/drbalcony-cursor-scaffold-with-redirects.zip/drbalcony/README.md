# drbalcony — Cursor Project

Single workspace for PPC pages, organic content, and shared components.

## Key Folders
- `ppc-pages/` — Paid landing pages (one folder per URL)
- `blog/` — Organic posts (one folder per URL)
- `components/` — Reusable UI (no page-specific content)
- `wordpress-snippets/` — PHP/shortcodes/snippets to paste into WP
- `assets/` — Images, styles, icons
- `sop/` — Editorial and on-page SOPs (Markdown)
- `ops/redirects/` — Redirect CSVs, rules, notes
- `ops/speed-checklist/` — Perf tasks & tracking
- `ops/internal-linking/` — Link maps & tasks