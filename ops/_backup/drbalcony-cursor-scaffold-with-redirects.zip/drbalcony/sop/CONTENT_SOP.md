# Universal Content SOP (Working Copy)

Use this as a working Markdown SOP copied from the spreadsheet.
Suggested sections:
1) Brief template
2) Outline checklist
3) On-page SEO checklist
4) Publishing QA checklist
5) Internal linking plan
6) GA4/UTM tracking notes

Tip: keep each section short and link to deeper docs in `/ops/`.