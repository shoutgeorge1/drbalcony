# Brief Template

**URL:** /path-here
**Owner:** Name
**Priority:** High/Med/Low
**Audience & Intent:** 
**Primary KW:** 
**Secondaries:** 
**Offer/CTA:** 
**Hero Angle:** 
**Competitor References:**