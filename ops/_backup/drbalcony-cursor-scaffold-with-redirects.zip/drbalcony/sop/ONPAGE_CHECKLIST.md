# On-Page SEO Checklist

- Title: <= 60 chars, primary KW near front
- Meta description: compelling, <= 155 chars
- H1 unique, 1 per page; H2/H3 structured
- Intro matches search intent within 100–150 words
- Internal links (>=3) to relevant pages
- Outbound citation(s) if appropriate
- Images compressed, alt text informative
- Schema (as needed): Article/FAQ/HowTo/LocalBusiness
- Core Web Vitals friendly layout
- Final QA passed (typos, links, forms)