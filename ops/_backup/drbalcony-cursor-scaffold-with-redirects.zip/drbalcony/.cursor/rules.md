# Cursor Rules

- Treat this folder as the project root.
- Prefer creating new pages inside `ppc-pages/` or `blog/`.
- Reuse components from `components/` (do not duplicate CSS/JS).
- Store SOPs and checklists in `sop/` as Markdown or CSV in `ops/`.