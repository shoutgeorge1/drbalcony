# Redirect & Canonical Mapping Rules

- [—] SB-326 topics → /what-is-the-california-senate-bill-326/
- [—] SB-721 topics → /sb-721-inspection-requirements/
- [—] Balcony inspection (general) → /california-balcony-inspections-deadline-extended-to-january-1-2026/
- [—] Deck inspection → /deck-inspection-requirements-what-homeowners-should-know/
- [—] Waterproofing / drainage → /balcony-drainage-systems-design-maintenance-and-inspection-best-practices/
- [—] Railing code → /what-is-balcony-railing-height-code-in-california/
- [—] Load / weight → /understanding-balcony-load-limits/
- [—] Everything else thin/duplicate → / (homepage)
